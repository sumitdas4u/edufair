apiUrl='http://localhost/user/api/public/';
 apiConfig = {
    loginApi : apiUrl+'auth/login',
    userRegister : apiUrl+'register',
    chatSetUnread : apiUrl+'chat/setunreadmessage',
    chatUnreadSeen : apiUrl+'chat/unreadmessageseen',
    chatUserThread : apiUrl+'user/chatthreads'

}

